  <!--/ Section Contact-Footer Star /-->
  <section class="paralax-mf footer-paralax bg-image sect-mt4 route" style="background-image: url(assets/front/img/overlay-bg.jpg)">
    <div class="overlay-mf"></div>
    <footer>
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div class="copyright-box">
						<p class="copyright">&copy; Copyright <strong>Akhirwan Novendi</strong>. All Rights Reserved</p>
						<div class="credits">2019</a></div>
					</div>
				</div>
			</div>
		</div>
	</footer>
</section>
  <!--/ Section Contact-footer End /-->
  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>
  <div id="preloader"></div>

  <!-- JavaScript Libraries -->
  <script src="<?php echo base_url(); ?>assets/front/lib/jquery/jquery.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/front/lib/jquery/jquery-migrate.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/front/lib/popper/popper.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/front/lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/front/lib/easing/easing.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/front/lib/counterup/jquery.waypoints.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/front/lib/counterup/jquery.counterup.js"></script>
  <script src="<?php echo base_url(); ?>assets/front/lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/front/lib/lightbox/js/lightbox.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/front/lib/typed/typed.min.js"></script>
  <!-- Contact Form JavaScript File -->
  <script src="<?php echo base_url(); ?>assets/front/contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="<?php echo base_url(); ?>assets/front/js/main.js"></script>

</body>
</html>
